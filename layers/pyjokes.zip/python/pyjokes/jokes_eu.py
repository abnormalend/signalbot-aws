# -*- coding: utf-8 -*-

# BASQUE

neutral = [
    "Zer dira 8 Bocabits? BocaByte bat",
    "Zer esaten dio bit batek besteari? Busean ikusten gara!",
    "Zer da terapeuta bat? - 1024 Gigapeuta",
    "Aita, aita, aita!!! Utziko al didazu telebista ikusten? Bai! Baina pizten ez!",
    "Matematika liburu batek bere buruaz beste egin zuen... zergatik? Problema asko zituelako.",
]

jokes_eu = {"neutral": neutral, "all": neutral}
