from .pyjokes import get_joke, get_jokes, LANGUAGE_VALUES, CATEGORY_VALUES
