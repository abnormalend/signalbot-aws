# -*- coding: utf-8 -*-

# CZECH

neutral = [
    "Webmaster vyplňuje dotazník: Věk: 25 Výška: 185 Barva očí: #4040FF",
    "Víte, proč blondýna pokládá vedle počítače sýr? Aby měla myš co jíst!",
    "Za manžela jsem si vzala programátora. Když jsem se ho zeptala, jak mám otevřít jar, řekl mi, abych si stáhla Javu.",
    "Před chvílí jsem zažil nejrychlejší přenos dat v životě, 256 GB za sekundu. Vysavač mi vcucl flešku.",
    "Vnouček křičí: Babi, jdeme koupit playstation! Babička odpoví: Kupte si co chcete, já to krmit nebudu!",
    "A Bůh pravil: Noe, udělej zálohu.. budu formátovat.",
    "Víte co dělá windows na měsíci? Padá 6 krát pomaleji",
    "Bavi se dva admini: Kámoš včera během 5 minut shodil hlavní server. On je hacker? Ne, debil.",
    "Baví se dva grafici: Já jsem sbalil novou holku a je krásná má 90-60-90 Cože? Tmavě fialová?",
    "Kdo se směje naposledy, má největší ping.",
    "Ženy jsou jako internetové domény. Ty nejlepší už jsou zabrané. Ovšem vždycky je tu možnost najít si nějakou z exotické země.",
    "Ptali se mě, jestli vůbec mám přátele. Jasně, že mám. Všechny díly.",
    "Co volá programátor, když se topí?F1, F1, F1!",
    "A znáte ten, jak přijde programátor v neděli ráno do posilovny?",
    "Přide hacker ke knězi a povídá: Otče zhrešil jsem. A kolik toho máš? No vešlo se to na dvě diskety!",
    "Tři největší katastrofy v historii lidstva: Hiroshima 45, Černobyl 86, Windows 95",
    "Padá server, přej si něco !",
    "Na jakém hardware běží Windows 98 nejlépe? Na diaprojektoru.",
    "Svět je binární. Buď jste jednička nebo nula.",
    "Informatik je člověk, který se v potravinách diví, že kilo masa neváží 1024 gramů.",
    "Někdy je lepší zůstat v pondělí v posteli než celý týden ladit pondělní kód.",
    "Všichni mi říkají, že jméno kocoura se jako heslo pro roota nehodí. Ale když já jsem si už na svýho qzb!7kw_2et tak zvykl!",
    "S UDP vtipy je ten problém, že nikdy nevíte, jestli lidem došly.",
    "Už jsem na řadě s vyprávěním vtipu o Token-ringu?",
    "Problém CSS vtipů je, že je každý pochopí trochu jinak.",
    "Přijde IPv6 paket do baru. Nikdo se s ním nebaví.",
    "Přijde multicastový paket do baru a odejde čtyřmi východy současně.",
    "Kolik programátorů je potřeba k výměně žárovky ? Žádný. To je problém hardwaru.",
    "Které místo v Praze je pojmenováno na počest Internetu? Náměstí I.P. Pavlova.",
]

chuck = [
    "Chuck Norris nepotřebuje klávesnici a myš. Počítač ho poslouchá na slovo",
    "Binární kód počítače obsahuje jedničky a nuly. Binární kód Chuck Norrisova mozku obsahuje pouze jedničky.",
    "Jen Chuck Norris vás dokáže uškrtit bezdrátovou myší.",
    "Chuck Norris píše kód, který se sám optimalizuje.",
    "První program od Chucka Norrise byl zabit -9.",
    "Chuck Norris umí psát nekonečné rekurzní funkce a nechat je vrátit se.",
    "Chuck Norris umí smazat Koš.",
    "Chuck Norris umí dělit nulou.",
    "Chuck Norris umí psát na ROM.",
    "Chuck Norris nepotřebuje debugger, jen zírá na chybu dokud se kód nepřizná.",
    "Hosting u Chucka Norrise je garantován dostupnosti 105 procent.",
    "Chuck Norris vyhrál soutěž Ahoj světe pod 20 bajtů vytvořením jednobajtového programu.",
]

jokes_cs = {
    "neutral": neutral,
    "chuck": chuck,
    "all": neutral + chuck,
}
